import React from "react";
import Login from "./pages/Login";
import MapView from "./components/MapView";

function App() {
  return (
    <div>
      <h1 style={{textAlign: 'center'}}>ShareRide</h1>
      <Login />
      <div style={{height: '60vh', marginTop: 20}}>
        <MapView />
      </div>
    </div>
  );
}

export default App;
