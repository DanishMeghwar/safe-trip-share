ShareRide - Starter scaffold (Vite + React + Capacitor)

What's included:
- Vite React app scaffold
- Capacitor config (com.shareride.app)
- Firebase scaffolding file (src/firebaseConfig.ts)
- MapLibre React component (src/components/MapView.tsx)
- Login page (src/pages/Login.tsx)
- Minimal App (src/App.tsx)
- GitHub Actions workflow to build & produce APK

How to use (recommended: GitHub Actions):
1. Upload this project to your GitHub repo (replace existing files).
2. Commit and push to the main branch.
3. In your repo create the workflow file .github/workflows/android-build.yml (we include it in this zip).
4. Go to Actions → run the Android Build workflow. The APK will be available as an artifact.

If you want to build locally on Termux (advanced):
- Install nodejs and npm in Termux
- npm install
- npm run build
- npx cap add android
- npx cap sync android
- cd android && chmod +x ./gradlew && ./gradlew assembleDebug
