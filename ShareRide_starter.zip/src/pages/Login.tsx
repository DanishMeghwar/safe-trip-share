import React, { useState } from "react";
import { auth, googleProvider } from "../firebaseConfig";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signInWithPopup } from "firebase/auth";

const Login: React.FC = () => {
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");

  const handleEmail = async () => {
    try {
      const res = await signInWithEmailAndPassword(auth, email, pw);
      alert("Welcome " + res.user.email);
    } catch (e) {
      try {
        const res2 = await createUserWithEmailAndPassword(auth, email, pw);
        alert("User created: " + res2.user.email);
      } catch (err) {
        alert(err);
      }
    }
  };

  const handleGoogle = async () => {
    try {
      const r = await signInWithPopup(auth, googleProvider);
      alert("Welcome " + r.user.displayName);
    } catch (err) {
      alert(err);
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>ShareRide — Login</h2>
      <input placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} /><br/>
      <input placeholder="Password" type="password" value={pw} onChange={(e)=>setPw(e.target.value)} /><br/>
      <button onClick={handleEmail}>Login / Signup</button>
      <hr/>
      <button onClick={handleGoogle}>Sign in with Google</button>
    </div>
  );
};

export default Login;
